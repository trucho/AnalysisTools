MAX/MSP:
Unzip to "..\Cycling '74\Max 5.0\Cycling '74\java".
Alternatively, edit the "max.java.config.txt" to point to the "core.jar" in the lib-directory
and classes in the "classes" directory.

MATLAB:
Run "install.m" to add "core.jar"  to your classpath.
Or do it manually by editing the "classpath.txt" in "[matlabroot]/toolbox/local"

NOTE:
There are two different "Processing.java"s.
One has MAX/MSP support, but requires the "max.jar" (in the maxmsp package),
the other doesn't have it (in the Processing package).

They only differ a few lines of code, so you might want to delete the version that you don't need 
to avoid confusion. You can also use the MAX/MSP version in Matlab if you add the "max.jar"!

MORE INFORMATION:
Read the comments in "processing.java", or try the example patch / m-file.